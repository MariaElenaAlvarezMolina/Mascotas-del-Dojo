from Ninja import Ninja
from Mascota2 import Mascota2

Ninja1 = Ninja("Shu", "I", "juguete", "pellet", "Rocky", "perro", "croquetas")


Ninja1.mascota.dormir()

Ninja1.mascota.comer()

Ninja1.mascota.jugar()

Ninja1.mascota.sonido()

Ninja1.caminar()

Ninja1.alimentar()

Ninja1.bañar()

#Herencia
Michi = Mascota2("Michi", "gato", "pescado")
Michi.dormir()